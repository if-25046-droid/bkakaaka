SISTEM PEMESANAN COFFEE SHOP - MVC + EXCEPTION INTERFACE

Struktur:
- src/model/MenuItem.java: abstract class menu.
- src/model/Kopi.java, Teh.java, Roti.java: model konkret dan implementasi Customizable.
- src/model/Customizable.java: interface customization dengan method overloading.
- src/model/EnumUkuran.java: enum ukuran.
- src/model/exception/: custom exception yang extends Exception (sesuai ketentuan soal).
- src/controller/ExceptionHandler.java: interface terpisah untuk kontrak penanganan exception.
- src/controller/CoffeeShopController.java: controller mengimplementasikan ExceptionHandler dan menangani exception dengan try-catch.
- src/view/CoffeeShopView.java: input/output.
- src/Main.java: titik awal program.

Cara compile dari folder proyek:
  javac -d out src/model/*.java src/model/exception/*.java src/view/*.java src/controller/*.java src/Main.java

Cara menjalankan:
  java -cp out Main

Catatan:
Interface ExceptionHandler bukan pengganti custom exception. Custom exception tetap class turunan Exception, sedangkan interface ExceptionHandler berada terpisah di package controller dan diimplementasikan oleh CoffeeShopController. Ini menjaga kesesuaian dengan soal UTS.
Kode promo: HEMAT10 memberi diskon 10%.
