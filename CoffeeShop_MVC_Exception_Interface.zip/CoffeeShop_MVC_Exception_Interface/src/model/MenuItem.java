package model;

public abstract class MenuItem {
    protected String id;
    protected String nama;
    protected double hargaBase;
    protected int stok;

    public MenuItem(String id, String nama, double hargaBase, int stok) {
        this.id = id;
        this.nama = nama;
        this.hargaBase = hargaBase;
        this.stok = stok;
    }

    public abstract double hitungHargaTotal();
    public abstract String getOrderDetail();

    public double hitungHargaTotal(int jumlah) {
        return hitungHargaTotal() * jumlah;
    }

    public double hitungHargaTotal(int jumlah, String kodePromo) {
        double total = hitungHargaTotal(jumlah);
        if ("HEMAT10".equalsIgnoreCase(kodePromo)) total *= 0.90;
        return total;
    }

    public double hitungHargaTotal(int jumlah, EnumUkuran ukuran) {
        double pengali = switch (ukuran) {
            case SMALL -> 1.0;
            case MEDIUM -> 1.2;
            case LARGE -> 1.5;
        };
        return hitungHargaTotal() * jumlah * pengali;
    }

    public String getId() { return id; }
    public String getNama() { return nama; }
    public int getStok() { return stok; }
    public double getHargaBase() { return hargaBase; }
    public void kurangiStok(int jumlah) { stok -= jumlah; }

    public String toString() {
        return id + ": " + nama + " (Rp" + String.format("%.0f", hargaBase) + ", Stok: " + stok + ")";
    }
}
