package model;

import java.util.List;

public class Teh extends MenuItem implements Customizable {
    private int boba, es, gula, karamel;

    public Teh(String id, String nama, double hargaBase, int stok) {
        super(id, nama, hargaBase, stok);
    }
    public void customize(List<Integer> c) {
        if (c.size() >= 4) { boba = c.get(0); es = c.get(1); gula = c.get(2); karamel = c.get(3); }
    }
    public void customize(int[] c) {
        if (c.length >= 4) { boba = c[0]; es = c[1]; gula = c[2]; karamel = c[3]; }
    }
    public double hitungHargaTotal() { return hargaBase + boba * 1000 + karamel * 3000; }
    public String getOrderDetail() { return nama + " | Boba: " + boba + ", Es: " + es + ", Gula: " + gula + ", Karamel: " + karamel; }
}
