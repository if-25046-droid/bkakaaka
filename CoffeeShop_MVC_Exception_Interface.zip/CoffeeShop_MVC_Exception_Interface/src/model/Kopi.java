package model;

import java.util.List;

public class Kopi extends MenuItem implements Customizable {
    private int rum, es, gula, karamel;

    public Kopi(String id, String nama, double hargaBase, int stok) {
        super(id, nama, hargaBase, stok);
    }

    public void customize(List<Integer> c) {
        if (c.size() >= 4) { rum = c.get(0); es = c.get(1); gula = c.get(2); karamel = c.get(3); }
    }
    public void customize(int[] c) {
        if (c.length >= 4) { rum = c[0]; es = c[1]; gula = c[2]; karamel = c[3]; }
    }
    public double hitungHargaTotal() { return hargaBase + rum * 3000 + karamel * 3000; }
    public String getOrderDetail() { return nama + " | Rum: " + rum + ", Es: " + es + ", Gula: " + gula + ", Karamel: " + karamel; }
}
