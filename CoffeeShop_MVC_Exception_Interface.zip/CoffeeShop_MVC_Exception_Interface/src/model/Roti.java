package model;

import java.util.List;

public class Roti extends MenuItem implements Customizable {
    private int gula, meses, karamel;

    public Roti(String id, String nama, double hargaBase, int stok) {
        super(id, nama, hargaBase, stok);
    }
    public void customize(List<Integer> c) {
        if (c.size() >= 3) { gula = c.get(0); meses = c.get(1); karamel = c.get(2); }
    }
    public void customize(int[] c) {
        if (c.length >= 3) { gula = c[0]; meses = c[1]; karamel = c[2]; }
    }
    public double hitungHargaTotal() { return hargaBase + meses * 500 + karamel * 3000; }
    public String getOrderDetail() { return nama + " | Gula: " + gula + ", Meses: " + meses + ", Karamel: " + karamel; }
}
