package controller;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import model.*;
import model.exception.InputTidakValidException;
import model.exception.MenuTidakDitemukanException;
import model.exception.StokTidakCukupException;
import view.CoffeeShopView;

public class CoffeeShopController implements ExceptionHandler {
    private final List<MenuItem> menu = new ArrayList<>();
    private final CoffeeShopView view;

    public CoffeeShopController(CoffeeShopView view) {
        this.view = view;
        menu.add(new Kopi("M-01", "Kopi Susu", 18000, 5));
        menu.add(new Teh("M-02", "Teh Tarik", 15000, 10));
        menu.add(new Roti("M-03", "Roti Cokelat", 12000, 8));
    }

    public void jalankan() {
        boolean lanjut = true;
        while (lanjut) {
            view.tampilkanMenu(menu);
            String id = view.input("Masukkan ID menu (0 untuk keluar): ");
            if (id.equals("0")) { lanjut = false; continue; }
            try {
                MenuItem item = cariMenu(id);
                int jumlah = bacaJumlah(view.input("Jumlah pesanan: "));
                if (jumlah > item.getStok()) {
                    throw new StokTidakCukupException("Stok " + item.getNama() + " hanya tersisa " + item.getStok() + ".");
                }
                if (item instanceof Customizable customizable) {
                    if (item instanceof Kopi) {
                        int[] c = inputKustomisasi("Rum", "Es", "Gula", "Karamel");
                        customizable.customize(c);
                    } else if (item instanceof Teh) {
                        int[] c = inputKustomisasi("Boba", "Es", "Gula", "Karamel");
                        customizable.customize(c);
                    } else if (item instanceof Roti) {
                        int[] c = inputKustomisasi("Gula", "Meses", "Karamel");
                        customizable.customize(c);
                    }
                }
                String promo = view.input("Kode promo (Enter jika tidak ada, HEMAT10 untuk diskon 10%): ");
                double total = promo.isBlank() ? item.hitungHargaTotal(jumlah) : item.hitungHargaTotal(jumlah, promo);
                item.kurangiStok(jumlah);
                view.tampilkanStruk(item.getOrderDetail(), jumlah, total);
            } catch (MenuTidakDitemukanException | StokTidakCukupException | InputTidakValidException e) {
                handleException(e);
            } catch (NumberFormatException e) {
                handleException(new InputTidakValidException("Input harus berupa angka yang valid."));
            }
        }
        view.tampilkanPesan("Terima kasih sudah memesan!");
    }

    private MenuItem cariMenu(String id) throws MenuTidakDitemukanException {
        for (MenuItem item : menu) if (item.getId().equalsIgnoreCase(id)) return item;
        throw new MenuTidakDitemukanException("ID menu '" + id + "' tidak terdaftar.");
    }

    private int bacaJumlah(String teks) throws InputTidakValidException {
        int jumlah = Integer.parseInt(teks);
        if (jumlah <= 0) throw new InputTidakValidException("Jumlah pesanan harus lebih besar dari 0.");
        return jumlah;
    }

    private int[] inputKustomisasi(String... nama) throws InputTidakValidException {
        int[] hasil = new int[nama.length];
        for (int i = 0; i < nama.length; i++) {
            int nilai = Integer.parseInt(view.input("Jumlah " + nama[i] + " (0 jika tidak ada): "));
            int batas = nama[i].equals("Rum") ? 1 : nama[i].equals("Boba") ? 3 : 5;
            if (nilai < 0 || nilai > batas) throw new InputTidakValidException("Jumlah " + nama[i] + " harus antara 0 dan " + batas + ".");
            hasil[i] = nilai;
        }
        return hasil;
    }

    @Override
    public void handleException(Exception exception) {
        view.tampilkanPesan("Pesanan gagal: " + exception.getMessage());
    }
}
