package controller;

public interface ExceptionHandler {
    void handleException(Exception exception);
}
