package view;

import java.util.List;
import java.util.Scanner;
import model.MenuItem;

public class CoffeeShopView {
    private final Scanner scanner = new Scanner(System.in);

    public void tampilkanMenu(List<MenuItem> menu) {
        System.out.println("\n=== MENU COFFEE SHOP ===");
        for (MenuItem item : menu) System.out.println(item);
    }
    public String input(String pesan) {
        System.out.print(pesan);
        return scanner.nextLine().trim();
    }
    public void tampilkanPesan(String pesan) { System.out.println(pesan); }
    public void tampilkanStruk(String detail, int jumlah, double total) {
        System.out.println("\n=== STRUK PESANAN ===");
        System.out.println(detail);
        System.out.println("Jumlah: " + jumlah);
        System.out.printf("Total: Rp%.0f%n", total);
    }
}
